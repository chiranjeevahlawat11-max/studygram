package com.studyfeed.android.classifier

import com.studyfeed.android.syllabus.NcertSyllabus

enum class Decision { EDUCATIONAL, UNRELATED, UNCERTAIN }

data class Classification(
    val decision: Decision,
    val matchedSubjects: List<String>,
    val matchedChapterIds: List<String>,
    val topicScore: Int,
    val teachingSignals: Int,
    val distractionSignals: Int,
    val reason: String
)

/**
 * Offline, transparent rules engine. NOT an AI model and NOT perfectly accurate.
 *
 * Kept from Milestone 2: the idea of requiring a syllabus topic AND a teaching signal.
 * Changed:
 *  - whole-word matching (the old substring match treated "base" in "baseball" as Science)
 *  - weighted syllabus keywords from every enabled chapter
 *  - distraction words that outvote a stray hashtag (#ncert on a meme is still blocked)
 *  - uncertain content is never allowed through
 */
object ContentClassifier {

    private const val MIN_CHARS = 30
    private const val LONG_TEXT_CHARS = 60

    private class Term(val chapterId: String, val subject: String, val weight: Int, val regex: Regex)

    private val terms: List<Term> by lazy {
        val out = ArrayList<Term>()
        for (subject in NcertSyllabus.subjects) for (chapter in subject.chapters) {
            for (raw in chapter.keywords) {
                val weak = raw.startsWith("~")
                val kw = normalise(raw.removePrefix("~"))
                if (kw.isEmpty()) continue
                val strong = !weak && (kw.contains(' ') || kw.contains('-') || kw.length >= 10)
                out += Term(chapter.id, subject.name, if (strong) 2 else 1, wholeWord(kw))
            }
        }
        out
    }

    private val teachingSignals: List<Regex> = listOf(
        "class 10", "class x", "10th", "cbse", "ncert", "chapter", "board exam", "boards", "formula",
        "definition", "explained", "explanation", "solution", "solved", "numerical", "important questions",
        "mcq", "revision", "notes", "concept", "theorem", "proof", "derivation", "diagram", "exercise",
        "worksheet", "previous year", "pyq", "lecture", "tutorial", "syllabus", "sample paper",
        "प्रश्न", "उत्तर", "व्याख्या", "सारांश", "अध्याय", "कक्षा 10", "नोट्स", "परीक्षा", "पाठ"
    ).map { wholeWord(normalise(it)) }

    private val distractionSignals: List<Regex> = listOf(
        "meme", "funny", "prank", "comedy", "roast", "dance", "trending", "viral", "challenge",
        "bgmi", "free fire", "pubg", "minecraft", "gaming", "gameplay", "streamer", "movie", "trailer",
        "web series", "celebrity", "bollywood", "song", "lyrics", "ipl", "fashion", "outfit", "makeup",
        "grwm", "giveaway", "reaction video", "unboxing", "haul", "dating", "crush", "boyfriend",
        "girlfriend", "gossip", "shorts", "vlog", "reels challenge", "follow for more"
    ).map { wholeWord(normalise(it)) }

    fun normalise(s: String): String =
        s.lowercase()
            .replace('\u2019', '\'').replace('\u2018', '\'')
            .replace('\u2013', '-').replace('\u2014', '-')
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun wholeWord(kw: String): Regex =
        Regex("(?<![\\p{L}\\p{M}\\p{N}])" + Regex.escape(kw) + "(?:es|s)?(?![\\p{L}\\p{M}\\p{N}])")

    /**
     * @param enabledChapterIds chapters the user keeps switched on (null = syllabus defaults)
     */
    fun classify(rawText: String, enabledChapterIds: Set<String>? = null): Classification {
        val enabled = enabledChapterIds ?: NcertSyllabus.defaultEnabledIds()
        val text = normalise(rawText)

        if (text.length < MIN_CHARS) {
            return result(Decision.UNCERTAIN, emptyMap(), 0, 0, 0, "Not enough readable text")
        }

        // Best score per chapter, counting each distinct keyword once.
        val chapterScores = HashMap<String, Int>()
        val chapterSubject = HashMap<String, String>()
        for (t in terms) {
            if (t.chapterId !in enabled) continue
            if (t.regex.containsMatchIn(text)) {
                chapterScores[t.chapterId] = (chapterScores[t.chapterId] ?: 0) + t.weight
                chapterSubject[t.chapterId] = t.subject
            }
        }
        val topic = chapterScores.values.sum()
        val teaching = teachingSignals.count { it.containsMatchIn(text) }
        val distraction = distractionSignals.count { it.containsMatchIn(text) }

        val decision: Decision
        val reason: String
        when {
            distraction >= 2 && topic < 6 -> {
                decision = Decision.UNRELATED; reason = "Entertainment/distraction words outweigh study topics"
            }
            distraction == 0 && ((topic >= 3 && teaching >= 1) || (topic >= 2 && teaching >= 2)) -> {
                decision = Decision.EDUCATIONAL; reason = "Syllabus topic(s) plus teaching context"
            }
            distraction == 1 && topic >= 5 && teaching >= 2 -> {
                decision = Decision.EDUCATIONAL; reason = "Strong syllabus match despite one distraction word"
            }
            topic <= 1 && teaching == 0 && text.length >= LONG_TEXT_CHARS -> {
                decision = Decision.UNRELATED
                reason = if (topic == 0) "No syllabus topic found" else "Only a single weak syllabus word"
            }
            else -> {
                decision = Decision.UNCERTAIN
                reason = if (topic == 0) "Too little text to judge" else "Topic mentioned without enough teaching context"
            }
        }
        return result(decision, chapterSubject, topic, teaching, distraction, reason, chapterScores.keys)
    }

    private fun result(
        d: Decision, subjects: Map<String, String>, topic: Int, teaching: Int, distraction: Int,
        reason: String, chapterIds: Set<String> = emptySet()
    ) = Classification(
        d, subjects.values.distinct().sorted(), chapterIds.sorted(), topic, teaching, distraction, reason
    )
}
