package com.studyfeed.android.syllabus

/**
 * One chapter and the phrases that identify it in captions / on-screen text.
 *
 * Keyword weights (see ContentClassifier):
 *  - a phrase with a space/hyphen, or a single word of 10+ letters, is STRONG (2 points)
 *  - a short single word is WEAK (1 point)
 *  - a leading "~" forces WEAK for broad words such as "~development"
 *
 * [defaultEnabled] = false means the chapter starts switched OFF because we could not
 * confirm it is in the current syllabus. The user can switch it on in the app.
 */
data class Chapter(
    val id: String,
    val title: String,
    val keywords: List<String>,
    val defaultEnabled: Boolean = true,
    val note: String? = null
)

data class Subject(val name: String, val group: String, val chapters: List<Chapter>)

private fun ch(
    id: String, title: String, vararg kw: String,
    on: Boolean = true, note: String? = null
) = Chapter(id, title, kw.toList(), on, note)

/**
 * STARTER SYLLABUS - NOT AUTHORITATIVE.
 * Built from the rationalised NCERT Class 10 books. We could not download the official CBSE
 * PDFs while building, so every chapter has an ON/OFF switch in the app. Check the list
 * against https://cbseacademic.nic.in (Curriculum > Secondary) for the current session and
 * switch off anything that has been removed.
 */
object NcertSyllabus {

    const val OFFICIAL_SYLLABUS_URL = "https://cbseacademic.nic.in"

    val subjects: List<Subject> = listOf(
        Subject("Science", "Science", listOf(
            ch("sci-1", "Chemical Reactions and Equations", "chemical reaction", "chemical equation",
                "balanced equation", "balancing equation", "combination reaction", "decomposition reaction",
                "displacement reaction", "double displacement", "redox", "oxidation", "corrosion",
                "rancidity", "precipitate", "exothermic", "endothermic"),
            ch("sci-2", "Acids, Bases and Salts", "acids bases and salts", "ph scale", "litmus",
                "neutralisation", "neutralization", "baking soda", "washing soda", "bleaching powder",
                "plaster of paris", "hydrochloric acid", "sodium hydroxide", "universal indicator",
                "water of crystallisation", "strong acid", "acid and base"),
            ch("sci-3", "Metals and Non-metals", "metals and non-metals", "reactivity series",
                "ionic compound", "ionic bond", "malleable", "ductile", "amphoteric oxide", "thermit",
                "extraction of metals", "roasting", "calcination", "electrolytic refining", "galvanisation"),
            ch("sci-4", "Carbon and its Compounds", "carbon compound", "covalent bond", "homologous series",
                "functional group", "ethanol", "ethanoic acid", "saponification", "micelle", "isomer",
                "hydrocarbon", "alkane", "alkene", "alkyne", "catenation", "esterification",
                "tetravalency", "allotrope"),
            ch("sci-5", "Life Processes", "life processes", "photosynthesis", "respiration", "aerobic",
                "anaerobic", "stomata", "chlorophyll", "alveoli", "haemoglobin", "nephron", "excretion",
                "transpiration", "xylem", "phloem", "translocation", "peristalsis", "digestion", "villi"),
            ch("sci-6", "Control and Coordination", "control and coordination", "nervous system", "neuron",
                "reflex action", "reflex arc", "synapse", "hormone", "insulin", "adrenaline", "thyroxine",
                "auxin", "phototropism", "tropism", "gibberellin", "cytokinin", "abscisic acid", "endocrine"),
            ch("sci-7", "How do Organisms Reproduce?", "how do organisms reproduce", "asexual reproduction",
                "sexual reproduction", "binary fission", "budding", "regeneration", "vegetative propagation",
                "pollination", "fertilisation", "fertilization", "placenta", "puberty", "zygote",
                "menstrual cycle", "contraception", "spore formation", "fragmentation"),
            ch("sci-8", "Heredity", "heredity", "mendel", "dominant trait", "recessive trait", "monohybrid",
                "dihybrid", "genotype", "phenotype", "sex determination", "dna", "chromosome", "genetics",
                "inherited trait", "gene"),
            ch("sci-9", "Light - Reflection and Refraction", "reflection of light", "refraction of light",
                "concave mirror", "convex mirror", "convex lens", "concave lens", "focal length",
                "mirror formula", "lens formula", "power of a lens", "dioptre", "snell's law",
                "refractive index", "principal focus", "magnification", "ray diagram", "centre of curvature"),
            ch("sci-10", "The Human Eye and the Colourful World", "human eye", "myopia", "hypermetropia",
                "presbyopia", "cataract", "power of accommodation", "far point", "near point",
                "dispersion of light", "prism", "rainbow", "atmospheric refraction", "tyndall effect",
                "scattering of light", "retina", "cornea", "twinkling of stars", "defects of vision"),
            ch("sci-11", "Electricity", "electric current", "ohm's law", "ohms law", "resistance",
                "resistivity", "potential difference", "electric circuit", "series circuit",
                "parallel circuit", "electric power", "joule's law", "heating effect of current", "ammeter",
                "voltmeter", "rheostat", "kilowatt hour", "coulomb", "electric fuse"),
            ch("sci-12", "Magnetic Effects of Electric Current", "magnetic effects of electric current",
                "magnetic field", "field lines", "right-hand thumb rule", "fleming's left-hand rule",
                "fleming's right-hand rule", "electromagnetic induction", "electric motor",
                "electric generator", "solenoid", "electromagnet", "domestic electric circuit",
                "galvanometer", "short circuit", "earthing"),
            ch("sci-13", "Our Environment", "our environment", "food chain", "food web", "ecosystem",
                "trophic level", "ozone layer", "biodegradable", "non-biodegradable", "ten percent law",
                "10 per cent law", "decomposers", "biomagnification", "cfc", "waste disposal")
        )),

        Subject("Mathematics", "Mathematics", listOf(
            ch("mat-1", "Real Numbers", "real numbers", "fundamental theorem of arithmetic", "hcf", "lcm",
                "irrational number", "rational number", "prime factorisation", "decimal expansion",
                "terminating decimal", "composite number"),
            ch("mat-2", "Polynomials", "polynomial", "zeroes of a polynomial", "zeros of a polynomial",
                "quadratic polynomial", "cubic polynomial", "sum of zeroes", "product of zeroes",
                "degree of polynomial", "graph of polynomial", "relationship between zeroes and coefficients"),
            ch("mat-3", "Pair of Linear Equations in Two Variables", "pair of linear equations",
                "linear equations in two variables", "substitution method", "elimination method",
                "cross multiplication method", "inconsistent", "graphical method", "system of equations"),
            ch("mat-4", "Quadratic Equations", "quadratic equation", "discriminant", "nature of roots",
                "completing the square", "quadratic formula", "roots of a quadratic", "factorisation method"),
            ch("mat-5", "Arithmetic Progressions", "arithmetic progression", "common difference",
                "nth term", "sum of n terms", "arithmetic sequence", "first term"),
            ch("mat-6", "Triangles", "similar triangles", "basic proportionality theorem", "thales theorem",
                "criteria for similarity", "aaa similarity", "sss similarity", "sas similarity",
                "pythagoras theorem", "areas of similar triangles"),
            ch("mat-7", "Coordinate Geometry", "coordinate geometry", "distance formula", "section formula",
                "midpoint formula", "mid-point formula", "area of a triangle", "collinear points",
                "internal division", "cartesian plane"),
            ch("mat-8", "Introduction to Trigonometry", "trigonometry", "trigonometric ratios",
                "sin theta", "cos theta", "tan theta", "sec theta", "cosec theta", "cot theta",
                "trigonometric identities", "complementary angles"),
            ch("mat-9", "Some Applications of Trigonometry", "angle of elevation", "angle of depression",
                "line of sight", "heights and distances", "applications of trigonometry"),
            ch("mat-10", "Circles", "tangent to a circle", "tangents to a circle", "point of contact",
                "length of tangent", "secant", "two tangents from an external point"),
            ch("mat-11", "Areas Related to Circles", "areas related to circles", "sector of a circle",
                "segment of a circle", "area of sector", "length of arc", "minor sector", "major segment",
                "circumference", "arc length"),
            ch("mat-12", "Surface Areas and Volumes", "surface areas and volumes", "volume of a cone",
                "volume of a cylinder", "volume of a sphere", "hemisphere", "frustum",
                "curved surface area", "total surface area", "combination of solids", "conversion of solid"),
            ch("mat-13", "Statistics", "~statistics", "mean median mode", "mean of grouped data",
                "assumed mean method", "step deviation method", "modal class", "median class",
                "cumulative frequency", "ogive", "frequency distribution"),
            ch("mat-14", "Probability", "~probability", "equally likely outcomes", "sample space",
                "theoretical probability", "complementary events", "favourable outcomes", "playing cards",
                "sure event", "impossible event", "throwing a die")
        )),

        Subject("History", "Social Science", listOf(
            ch("his-1", "The Rise of Nationalism in Europe", "rise of nationalism in europe",
                "nationalism in europe", "french revolution", "napoleon", "giuseppe mazzini", "young italy",
                "unification of germany", "unification of italy", "otto von bismarck", "garibaldi",
                "congress of vienna", "zollverein", "frankfurt parliament", "romanticism", "nation state"),
            ch("his-2", "Nationalism in India", "nationalism in india", "non-cooperation movement",
                "civil disobedience movement", "salt march", "dandi march", "satyagraha", "rowlatt act",
                "jallianwala bagh", "khilafat", "poona pact", "swaraj", "simon commission", "champaran",
                "gandhi-irwin pact", "lahore session"),
            ch("his-3", "The Making of a Global World", "making of a global world", "silk route",
                "bretton woods", "great depression", "indentured labour", "rinderpest", "corn laws",
                "gold standard", "world economy"),
            ch("his-4", "The Age of Industrialisation", "age of industrialisation", "proto-industrialisation",
                "spinning jenny", "industrial revolution", "east india company", "gomastha", "flying shuttle",
                "jobber"),
            ch("his-5", "Print Culture and the Modern World", "print culture", "gutenberg", "printing press",
                "woodblock", "manuscript", "vernacular press act", "penny magazines", "chapbooks",
                "martin luther", "ninety-five theses", "lithography")
        )),

        Subject("Geography", "Social Science", listOf(
            ch("geo-1", "Resources and Development", "resources and development", "resource planning",
                "land resources", "alluvial soil", "black soil", "regur", "laterite soil", "soil erosion",
                "land use pattern", "renewable resources", "sustainable development", "agenda 21",
                "gully erosion"),
            ch("geo-2", "Forest and Wildlife Resources", "forest and wildlife", "project tiger",
                "biodiversity", "flora and fauna", "endangered species", "joint forest management",
                "reserved forests", "wildlife sanctuary", "chipko",
                note = "Some sessions assess this only in internal/periodic tests - verify."),
            ch("geo-3", "Water Resources", "water resources", "multipurpose river projects",
                "rainwater harvesting", "water scarcity", "hydraulic structures", "narmada bachao andolan",
                "tehri dam", "bamboo drip irrigation",
                note = "Some sessions assess this only in internal/periodic tests - verify."),
            ch("geo-4", "Agriculture", "~agriculture", "shifting agriculture", "plantation agriculture",
                "intensive subsistence", "rabi", "kharif", "zaid", "cropping pattern", "green revolution",
                "white revolution", "bhoodan", "gramdan", "cash crops"),
            ch("geo-5", "Minerals and Energy Resources", "minerals and energy resources", "ferrous minerals",
                "non-ferrous", "iron ore", "manganese", "bauxite", "mica", "conventional sources of energy",
                "non-conventional", "geothermal", "mineral belt", "conservation of minerals", "rat-hole mining"),
            ch("geo-6", "Manufacturing Industries", "manufacturing industries", "agro-based industries",
                "mineral-based industries", "cotton textile", "jute textile", "iron and steel industry",
                "cement industry", "industrial pollution", "petrochemical"),
            ch("geo-7", "Lifelines of National Economy", "lifelines of national economy",
                "golden quadrilateral", "national highways", "pipelines", "major sea ports",
                "border roads organisation", "international trade", "tourism as a trade")
        )),

        Subject("Political Science", "Social Science", listOf(
            ch("pol-1", "Power Sharing", "power sharing", "belgium and sri lanka", "majoritarianism",
                "community government", "horizontal distribution", "vertical distribution",
                "prudential reasons", "moral reasons"),
            ch("pol-2", "Federalism", "federalism", "union list", "state list", "concurrent list",
                "residuary subjects", "coming together federation", "holding together federation",
                "panchayati raj", "gram sabha", "language policy", "decentralisation", "linguistic states",
                "zilla parishad"),
            ch("pol-3", "Gender, Religion and Caste", "gender religion and caste", "gender division",
                "sexual division of labour", "feminist movements", "communalism", "secular state",
                "caste inequality", "caste and politics", "family laws"),
            ch("pol-4", "Political Parties", "political parties", "multi-party system", "two-party system",
                "anti-defection", "recognised party", "election commission", "ruling party",
                "opposition party", "party system"),
            ch("pol-5", "Outcomes of Democracy", "outcomes of democracy", "accountable government",
                "legitimate government", "reduction of inequality", "dignity and freedom", "~democracy",
                "accommodation of social diversity", "quality of democracy")
        )),

        Subject("Economics", "Social Science", listOf(
            ch("eco-1", "Development", "~development", "national income", "per capita income",
                "human development index", "sustainability of development", "life expectancy",
                "literacy rate", "infant mortality rate", "net attendance ratio", "public facilities"),
            ch("eco-2", "Sectors of the Indian Economy", "sectors of the indian economy", "primary sector",
                "secondary sector", "tertiary sector", "organised sector", "unorganised sector",
                "disguised unemployment", "underemployment", "mgnrega", "public sector", "private sector",
                "value added"),
            ch("eco-3", "Money and Credit", "money and credit", "double coincidence of wants",
                "barter system", "demand deposits", "formal sector loans", "informal sector credit",
                "self help group", "collateral", "terms of credit", "reserve bank of india",
                "modern forms of money"),
            ch("eco-4", "Globalisation and the Indian Economy", "globalisation and the indian economy",
                "multinational companies", "foreign investment", "liberalisation", "trade barriers",
                "special economic zones", "world trade organisation", "foreign trade", "outsourcing",
                "fair globalisation", "production across countries")
        )),

        Subject("English", "English", listOf(
            ch("eng-1", "First Flight - Prose", "a letter to god", "lencho", "henri fricke",
                "nelson mandela", "long walk to freedom", "two stories about flying", "his first flight",
                "the black aeroplane", "from the diary of anne frank", "anne frank", "the hundred dresses",
                "wanda petronski", "glimpses of india", "a baker from goa", "coorg", "tea from assam",
                "mijbil the otter", "madam rides the bus", "valli", "the sermon at benares",
                "the proposal", "chubukov"),
            ch("eng-2", "First Flight - Poems", "dust of snow", "fire and ice", "a tiger in the zoo",
                "how to tell wild animals", "the ball poem", "amanda!", "the trees", "fog",
                "the tale of custard the dragon", "for anne gregory"),
            ch("eng-3", "Footprints Without Feet", "footprints without feet", "a triumph of surgery",
                "the thief's story", "the midnight visitor", "a question of trust", "the making of a scientist",
                "the necklace", "bholi", "the book that saved the earth", "griffin", "horace danby"),
            ch("eng-4", "Grammar and Writing", "reported speech", "subject-verb agreement", "determiners",
                "modals", "tenses", "gap filling", "editing and omission", "formal letter", "analytical paragraph",
                "letter writing", "~grammar")
        )),

        Subject("Hindi", "Hindi", listOf(
            ch("hin-1", "क्षितिज भाग 2 (गद्य)", "क्षितिज", "नेताजी का चश्मा", "बालगोबिन भगत", "लखनवी अंदाज़",
                "लखनवी अंदाज", "मानवीय करुणा की दिव्य चमक", "एक कहानी यह भी", "नौबतखाने में इबादत",
                "स्त्री शिक्षा के विरोधी कुतर्कों का खंडन", "संस्कृति"),
            ch("hin-2", "क्षितिज भाग 2 (काव्य)", "सूरदास", "राम-लक्ष्मण-परशुराम संवाद", "तुलसीदास", "सवैया और कवित्त",
                "आत्मकथ्य", "उत्साह", "अट नहीं रही है", "यह दंतुरित मुस्कान", "फसल", "छाया मत छूना", "कन्यादान",
                "संगतकार"),
            ch("hin-3", "कृतिका भाग 2", "कृतिका", "माता का आँचल", "जॉर्ज पंचम की नाक", "साना-साना हाथ जोड़ि",
                "एही ठैयाँ झुलनी हेरानी हो रामा", "मैं क्यों लिखता हूँ"),
            ch("hin-4", "स्पर्श भाग 2 / संचयन भाग 2 (हिंदी बी)", "स्पर्श", "संचयन", "हरिहर काका", "सपनों के-से दिन",
                "टोपी शुक्ला", "साखी", "मीरा के पद", "मनुष्यता", "पर्वत प्रदेश में पावस", "तोप", "कर चले हम फ़िदा"),
            ch("hin-5", "हिंदी व्याकरण", "पदबंध", "वाच्य", "मुहावरे", "रचना के आधार पर वाक्य", "वाक्य भेद",
                "पत्र लेखन", "अनुच्छेद लेखन", "विज्ञापन लेखन"),
            ch("hin-6", "समास और अलंकार", "समास", "अलंकार", "तत्पुरुष समास", "द्वंद्व समास", "अनुप्रास अलंकार",
                "उपमा अलंकार", "रूपक अलंकार",
                on = false,
                note = "Not confirmed for the current Class 10 syllabus. Ask your teacher, then switch on if needed.")
        )),

        Subject("Information Technology", "Information Technology", listOf(
            ch("it-1", "Employability Skills (Part A)", "communication skills", "self-management skills",
                "ict skills", "entrepreneurial skills", "green skills", "swot analysis", "sustainable development goals"),
            ch("it-2", "Digital Documentation", "digital documentation", "mail merge", "table of contents",
                "track changes", "styles and templates", "libreoffice writer", "master document"),
            ch("it-3", "Electronic Spreadsheet", "electronic spreadsheet", "vlookup", "pivot table",
                "what-if analysis", "goal seek", "scenario manager", "libreoffice calc", "absolute reference"),
            ch("it-4", "Database Management System", "database management system", "primary key",
                "foreign key", "relational database", "libreoffice base", "sql", "entity relationship"),
            ch("it-5", "Web Applications and Security", "web application", "cyber security", "phishing",
                "malware", "firewall", "cyber safety", "digital footprint", "online collaboration",
                note = "IT is an optional subject. Switch these chapters off if you do not take it.")
        ))
    )

    val allChapters: List<Chapter> get() = subjects.flatMap { it.chapters }

    fun defaultEnabledIds(): Set<String> =
        allChapters.filter { it.defaultEnabled }.map { it.id }.toSet()
}
