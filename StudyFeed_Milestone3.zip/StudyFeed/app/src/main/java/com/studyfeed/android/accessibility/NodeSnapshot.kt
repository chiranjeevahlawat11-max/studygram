package com.studyfeed.android.accessibility

/**
 * Plain-Kotlin copy of the parts of an accessibility node we use. Keeping this free of Android
 * classes lets the screen detector be unit-tested on a normal JVM.
 * Text of password and editable fields is never copied into a snapshot.
 */
data class NodeSnapshot(
    val text: String? = null,
    val description: String? = null,
    val viewId: String? = null,
    val selected: Boolean = false,
    val editable: Boolean = false,
    val children: List<NodeSnapshot> = emptyList()
) {
    fun flatten(): List<NodeSnapshot> {
        val out = ArrayList<NodeSnapshot>()
        val stack = ArrayDeque<NodeSnapshot>()
        stack.addLast(this)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            out += n
            for (i in n.children.indices.reversed()) stack.addLast(n.children[i])
        }
        return out
    }
}
