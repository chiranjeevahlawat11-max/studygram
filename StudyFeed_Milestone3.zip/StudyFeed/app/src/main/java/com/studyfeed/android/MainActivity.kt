package com.studyfeed.android

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.studyfeed.android.classifier.ContentClassifier
import com.studyfeed.android.classifier.Decision
import com.studyfeed.android.data.ProtectionPolicy
import com.studyfeed.android.data.SettingsStore
import com.studyfeed.android.syllabus.NcertSyllabus
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = SettingsStore(this)
        val actions = Actions(
            openAccessibility = { launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            openAppInfo = {
                launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            },
            openUrl = { url -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        )
        setContent { StudyFeedTheme { StudyFeedApp(store, resumeTick, actions) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    private fun launch(intent: Intent) {
        try { startActivity(intent) } catch (_: ActivityNotFoundException) { }
    }
}

class Actions(val openAccessibility: () -> Unit, val openAppInfo: () -> Unit, val openUrl: (String) -> Unit)

// ---------------------------------------------------------------- theme

private val LightColors = lightColorScheme(
    primary = Color(0xFF0E7490), onPrimary = Color.White,
    primaryContainer = Color(0xFFCFF3FA), onPrimaryContainer = Color(0xFF042F3B),
    secondary = Color(0xFF4F46E5), background = Color(0xFFF4F8FB), surface = Color.White,
    surfaceVariant = Color(0xFFE3EEF3), errorContainer = Color(0xFFFFE4E0)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF67D4EA), onPrimary = Color(0xFF00363F),
    primaryContainer = Color(0xFF0B4A5A), onPrimaryContainer = Color(0xFFCFF3FA),
    secondary = Color(0xFFA5B4FC), background = Color(0xFF0B1B2B), surface = Color(0xFF12263A),
    surfaceVariant = Color(0xFF1C3349)
)

@Composable
fun StudyFeedTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors, content = content)
}

// ---------------------------------------------------------------- shell

@Composable
fun StudyFeedApp(store: SettingsStore, tick: Int, actions: Actions) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { delay(1000); now = System.currentTimeMillis() }
    }
    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Filled.Home,
        "Syllabus" to Icons.Filled.Book,
        "Stats" to Icons.Filled.BarChart,
        "Settings" to Icons.Filled.SettingsIcon
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(t.second, contentDescription = null) },
                        label = { Text(t.first) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> DashboardScreen(store, now, tick, actions)
                1 -> SyllabusScreen(store, actions)
                2 -> StatsScreen(store, now)
                else -> SettingsScreen(store, now, tick, actions)
            }
        }
    }
}

@Composable
private fun Section(
    title: String, icon: ImageVector? = null, container: Color = MaterialTheme.colorScheme.surface,
    body: @Composable () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = container), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) { Icon(icon, contentDescription = null); Spacer(Modifier.width(8.dp)) }
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            body()
        }
    }
}

private fun mmss(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

// ---------------------------------------------------------------- dashboard

@Composable
private fun DashboardScreen(store: SettingsStore, now: Long, tick: Int, actions: Actions) {
    val context = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    var confirmOff by remember { mutableStateOf(false) }

    val serviceOn = remember(now, tick) { SettingsStore.isAccessibilityServiceEnabled(context) }
    val state = remember(now, tick, version) { ProtectionPolicy.resolve(store.protectionState(), now) }
    val active = ProtectionPolicy.isActive(state, now)
    val pending = ProtectionPolicy.isDisablePending(state, now)
    val stats = remember(now, version) { store.stats() }

    if (confirmOff) {
        AlertDialog(
            onDismissRequest = { confirmOff = false },
            title = { Text("Turn off protection?") },
            text = {
                Text("To stop impulsive switching-off, protection stays ON for another " +
                    "${ProtectionPolicy.COOLDOWN_MS / 60000} minutes after you confirm. You can cancel any time before then.")
            },
            confirmButton = {
                TextButton(onClick = {
                    store.saveProtectionState(ProtectionPolicy.requestDisable(store.protectionState(), System.currentTimeMillis()))
                    version++; confirmOff = false
                }) { Text("Start countdown") }
            },
            dismissButton = { TextButton(onClick = { confirmOff = false }) { Text("Keep it on") } }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("StudyFeed", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Instagram for CBSE Class 10 study content only",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            val good = serviceOn && active
            Section(
                title = when {
                    !serviceOn -> "Setup needed"
                    active -> "Protection is ON"
                    else -> "Protection is OFF"
                },
                icon = if (good) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                container = if (good) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
            ) {
                Text(when {
                    !serviceOn -> "The StudyFeed accessibility service is not turned on, so nothing is being filtered yet."
                    active -> "Only posts that look like Class 10 study content stay visible on Instagram."
                    else -> "Instagram is not being filtered right now."
                })
                if (serviceOn) {
                    when {
                        pending -> {
                            Text("Turning off in ${mmss(ProtectionPolicy.remainingMs(state, now))}", fontWeight = FontWeight.SemiBold)
                            OutlinedButton(onClick = {
                                store.saveProtectionState(ProtectionPolicy.cancelDisable(store.protectionState())); version++
                            }, modifier = Modifier.fillMaxWidth()) { Text("Keep protection on") }
                        }
                        active -> OutlinedButton(onClick = { confirmOff = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Turn off protection...")
                        }
                        else -> Button(onClick = {
                            store.saveProtectionState(ProtectionPolicy.enable()); version++
                        }, modifier = Modifier.fillMaxWidth()) { Text("Turn protection on") }
                    }
                }
            }
        }
        if (!serviceOn) {
            item {
                Section("Set up in 4 steps", Icons.Filled.Security) {
                    Text("1. Tap \"Open app info\", then the \u22EE menu (top right) and choose \"Allow restricted settings\". " +
                        "Android 13+ asks for this for apps installed outside Google Play. If there is no \u22EE menu, skip this step.")
                    Text("2. Tap \"Open Accessibility settings\" and find \"StudyFeed Instagram filter\" (under Installed apps or Downloaded apps).")
                    Text("3. Switch it ON and accept the prompt.")
                    Text("4. Come back here - the card above turns blue.")
                    Button(onClick = actions.openAppInfo, modifier = Modifier.fillMaxWidth()) { Text("Open app info") }
                    Button(onClick = actions.openAccessibility, modifier = Modifier.fillMaxWidth()) { Text("Open Accessibility settings") }
                }
            }
        }
        item {
            Section("Totals since last reset") {
                Text("Study screens allowed: ${stats.allowed}")
                Text("Screens blocked: ${stats.blocked}")
            }
        }
        item {
            Section("Why the Accessibility permission?") {
                Text("Android only lets an app read what is on another app's screen through an Accessibility service. " +
                    "StudyFeed uses it to read the visible text on Instagram, decide whether it is Class 10 study content, " +
                    "and cover the screen when it is not.")
                Text("\u2022 It checks the app is Instagram before reading anything.\n" +
                    "\u2022 It skips password fields, anything you type and direct messages.\n" +
                    "\u2022 No internet permission: nothing can leave your phone.\n" +
                    "\u2022 Only anonymous counters are stored, never captions.\n" +
                    "\u2022 Switch it off any time in Android Settings > Accessibility.")
            }
        }
    }
}

// ---------------------------------------------------------------- syllabus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SyllabusScreen(store: SettingsStore, actions: Actions) {
    var selected by rememberSaveable { mutableIntStateOf(0) }
    var enabled by remember { mutableStateOf(store.enabledChapterIds()) }
    val subjects = NcertSyllabus.subjects
    val subject = subjects[selected.coerceIn(0, subjects.size - 1)]
    val total = NcertSyllabus.allChapters.size
    val on = NcertSyllabus.allChapters.count { it.id in enabled }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Syllabus coverage", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("$on of $total chapters are being matched.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Section("Please verify", Icons.Filled.Warning, MaterialTheme.colorScheme.errorContainer) {
                Text("This list is a starter list built from the rationalised NCERT books. It could not be checked " +
                    "against the official CBSE PDF for the current session. Switch off any chapter your syllabus has removed.")
                OutlinedButton(onClick = { actions.openUrl(NcertSyllabus.OFFICIAL_SYLLABUS_URL) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Open the CBSE academic site")
                }
            }
        }
        item {
            ScrollableTabRow(selectedTabIndex = selected.coerceIn(0, subjects.size - 1), edgePadding = 0.dp) {
                subjects.forEachIndexed { i, s ->
                    Tab(selected = selected == i, onClick = { selected = i }, text = { Text(s.name) })
                }
            }
        }
        items(subject.chapters) { chapter ->
            ListItem(
                headlineContent = { Text(chapter.title) },
                supportingContent = { Text(chapter.note ?: "${chapter.keywords.size} topic phrases") },
                trailingContent = {
                    Switch(checked = chapter.id in enabled, onCheckedChange = { v ->
                        store.setChapterEnabled(chapter.id, v); enabled = store.enabledChapterIds()
                    })
                }
            )
            HorizontalDivider()
        }
        item {
            TextButton(onClick = { store.resetChapters(); enabled = store.enabledChapterIds() }) {
                Text("Reset chapters to defaults")
            }
        }
    }
}

// ---------------------------------------------------------------- stats

@Composable
private fun StatsScreen(store: SettingsStore, now: Long) {
    var version by remember { mutableIntStateOf(0) }
    val stats = remember(now, version) { store.stats() }
    val total = stats.total.coerceAtLeast(1L).toFloat()
    val since = java.text.DateFormat.getDateTimeInstance().format(java.util.Date(stats.sinceMs))

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Filtering statistics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Counting since $since", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Section("Allowed (educational)") {
                Text("${stats.allowed}", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { stats.allowed / total }, modifier = Modifier.fillMaxWidth())
            }
        }
        item {
            Section("Blocked: unrelated") {
                Text("${stats.blockedUnrelated}", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { stats.blockedUnrelated / total }, modifier = Modifier.fillMaxWidth())
            }
        }
        item {
            Section("Blocked: uncertain") {
                Text("${stats.blockedUncertain}", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { stats.blockedUncertain / total }, modifier = Modifier.fillMaxWidth())
                Text("\"Uncertain\" is blocked too: StudyFeed only lets content through when it is sure.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Text("These count screens StudyFeed judged, not individual posts. No text is saved.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { store.resetStats(); version++ }) { Text("Reset statistics") }
        }
    }
}

// ---------------------------------------------------------------- settings & troubleshooting

@Composable
private fun SettingsScreen(store: SettingsStore, now: Long, tick: Int, actions: Actions) {
    val context = LocalContext.current
    val serviceOn = remember(now, tick) { SettingsStore.isAccessibilityServiceEnabled(context) }
    val state = remember(now, tick) { ProtectionPolicy.resolve(store.protectionState(), now) }
    val beat = store.lastHeartbeat()
    var sample by rememberSaveable { mutableStateOf("") }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Settings & troubleshooting", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            Section("Health check") {
                Text("Accessibility service: " + if (serviceOn) "ON" else "OFF")
                Text("Protection: " + if (ProtectionPolicy.isActive(state, now)) "ON" else "OFF")
                Text("Last time StudyFeed saw Instagram: " +
                    if (beat == 0L) "never" else java.text.DateFormat.getDateTimeInstance().format(java.util.Date(beat)))
                OutlinedButton(onClick = actions.openAppInfo, modifier = Modifier.fillMaxWidth()) { Text("Open app info (restricted settings)") }
                OutlinedButton(onClick = actions.openAccessibility, modifier = Modifier.fillMaxWidth()) { Text("Open Accessibility settings") }
            }
        }
        item {
            Section("Try the classifier") {
                Text("Paste a caption to see how StudyFeed would judge it. Nothing is sent anywhere.",
                    style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = sample, onValueChange = { sample = it },
                    label = { Text("Caption or text") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                if (sample.isNotBlank()) {
                    val r = ContentClassifier.classify(sample, store.enabledChapterIds())
                    Text(when (r.decision) {
                        Decision.EDUCATIONAL -> "EDUCATIONAL - allowed"
                        Decision.UNRELATED -> "UNRELATED - blocked"
                        Decision.UNCERTAIN -> "UNCERTAIN - blocked"
                    }, fontWeight = FontWeight.Bold)
                    Text(r.reason)
                    if (r.matchedSubjects.isNotEmpty()) Text("Matched: " + r.matchedSubjects.joinToString())
                }
            }
        }
        item {
            Section("If something goes wrong") {
                Text("\u2022 Instagram is blocked completely: open Android Settings > Accessibility > StudyFeed Instagram filter and switch it OFF. This always works.\n" +
                    "\u2022 Nothing is being filtered: switch the service OFF and ON again, and make sure \"Allow restricted settings\" was done.\n" +
                    "\u2022 Filtering stopped after an Instagram update: Instagram changed its screen layout. The app fails open on screens it does not recognise.\n" +
                    "\u2022 Study posts get blocked: check the chapter is switched on in Syllabus, and try the classifier above.\n" +
                    "\u2022 Some phones stop background services to save battery: set StudyFeed to \"Unrestricted\" in app battery settings.")
            }
        }
        item {
            Section("Honest limits", Icons.Filled.Warning) {
                Text("\u2022 No normal app can stop you uninstalling it or switching off its Accessibility permission in Android Settings. " +
                    "StudyFeed adds a ${ProtectionPolicy.COOLDOWN_MS / 60000}-minute delay before protection can be turned off inside the app, and that is all it can legitimately do.\n" +
                    "\u2022 Matching is by keywords, not real understanding, so it makes mistakes both ways.\n" +
                    "\u2022 Posts with little or no readable text (many reels) are \"uncertain\" and blocked.\n" +
                    "\u2022 Stories, and Instagram screens StudyFeed does not recognise, are not filtered.\n" +
                    "\u2022 Instagram's layout can change at any time and break detection.")
            }
        }
    }
}
