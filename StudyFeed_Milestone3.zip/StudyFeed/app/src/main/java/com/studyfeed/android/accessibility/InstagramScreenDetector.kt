package com.studyfeed.android.accessibility

enum class InstagramSurface { FEED, EXPLORE, REELS, PROFILE, MESSAGES, OTHER }

/**
 * Decides which Instagram screen is showing, from the bottom tab bar's SELECTED tab.
 *
 * Privacy-first defaults (changed from Milestone 2):
 *  - Milestone 2 searched ALL screen text for words like "general", "primary", "audio", so a study
 *    post about "primary colours" was mistaken for a DM screen and never filtered. We now use
 *    structural signals only (view ids / exact node labels), never words inside post text.
 *  - If no selected tab is recognised the surface is OTHER: we neither read nor block anything.
 *
 * UNVERIFIED: the view ids / labels below come from how Instagram has looked in the past. They
 * could not be tested against a live Instagram here and WILL need adjusting when Instagram changes.
 */
object InstagramScreenDetector {

    private val tabIds = mapOf(
        "feed_tab" to InstagramSurface.FEED,
        "search_tab" to InstagramSurface.EXPLORE,
        "clips_tab" to InstagramSurface.REELS,
        "reels_tab" to InstagramSurface.REELS,
        "profile_tab" to InstagramSurface.PROFILE
    )

    private val tabLabels = mapOf(
        "home" to InstagramSurface.FEED,
        "search and explore" to InstagramSurface.EXPLORE,
        "reels" to InstagramSurface.REELS,
        "profile" to InstagramSurface.PROFILE
    )

    private val messagingIdParts = listOf("direct_thread", "row_thread", "message_list", "direct_text", "thread_title")

    fun detect(root: NodeSnapshot): InstagramSurface {
        val nodes = root.flatten()
        if (nodes.any { isMessagingNode(it) }) return InstagramSurface.MESSAGES
        val selected = nodes.firstOrNull { it.selected && tabOf(it) != null } ?: return InstagramSurface.OTHER
        return tabOf(selected) ?: InstagramSurface.OTHER
    }

    /** All text a person can currently read, excluding chrome (tab bar) and anything typed in. */
    fun extractContentText(root: NodeSnapshot, maxChars: Int = 6000): String {
        val parts = LinkedHashSet<String>()
        for (n in root.flatten()) {
            if (n.editable || tabOf(n) != null) continue
            n.text?.trim()?.takeIf { it.isNotEmpty() }?.let(parts::add)
            n.description?.trim()?.takeIf { it.isNotEmpty() }?.let(parts::add)
        }
        val joined = parts.joinToString(" ")
        return if (joined.length > maxChars) joined.substring(0, maxChars) else joined
    }

    private fun idName(n: NodeSnapshot): String = n.viewId?.substringAfter('/')?.lowercase() ?: ""

    private fun tabOf(n: NodeSnapshot): InstagramSurface? {
        tabIds[idName(n)]?.let { return it }
        val label = n.description?.trim()?.lowercase() ?: return null
        return tabLabels[label]
    }

    private fun isMessagingNode(n: NodeSnapshot): Boolean {
        val id = idName(n)
        if (id.isNotEmpty() && messagingIdParts.any { id.contains(it) }) return true
        return n.text?.trim()?.lowercase() == "message requests"
    }
}
