# StudyFeed (Milestone 3)

Android app that filters Instagram down to CBSE Class 10 study content, entirely on the phone.
Kotlin, Jetpack Compose, Material 3, AccessibilityService, local rules-based classifier.
Package: `com.studyfeed.android` - no INTERNET permission.

## Get the APK from your phone (no computer)
1. Create a free account at github.com and a **new repository** (Public or Private).
2. In the repository tap **Add file > Upload files**. Upload BOTH files you were given:
   `StudyFeed_Milestone3.zip` and `build-apk.yml`. Tap **Commit changes**.
3. Tap `build-apk.yml` > the pencil icon. In the filename box, put the cursor at the very start and type
   `.github/workflows/` so it reads `.github/workflows/build-apk.yml`. Tap **Commit changes**.
   (That commit starts the build. If it does not, open the **Actions** tab > **Build StudyFeed debug APK** > **Run workflow**.)
4. Wait 5-10 minutes in the **Actions** tab. A green tick = success.
   Download from the run page under **Artifacts** (a zip containing `app-debug.apk`), or from **Releases** (direct APK).
5. Open the APK. Android asks you to allow installs from your browser/Files app - allow it, then install.

## First launch
Follow the 4 setup steps on the Home screen. On Android 13+ you must first do
App info > ⋮ > **Allow restricted settings**, otherwise the accessibility switch stays greyed out.

## How filtering works
Reads only visible Instagram text, classifies it EDUCATIONAL / UNRELATED / UNCERTAIN with weighted whole-word
syllabus keywords, teaching signals ("class 10", "NCERT", "solved example"...) and distraction words.
Only EDUCATIONAL is left visible; the rest is covered by an overlay with **Next post** (scrolls on and re-checks)
and **Leave Instagram**. There is no "show anyway".

## Protection and its honest limits
- Turning protection off in the app only takes effect after a 10-minute countdown you can cancel.
- Android does not let a normal app prevent uninstalling it or revoking Accessibility. StudyFeed does not try to block
  Settings (that would trap you if it malfunctioned). Disabling it always works: Settings > Accessibility > StudyFeed.

## Test status (be skeptical, read this)
Done here: pure-Kotlin logic (classifier, screen detector, protection timer, syllabus data) compiled with kotlinc
and passed 54 local checks; the Android service/storage code type-checked against android.jar (API 34 stubs).
NOT done here: Gradle build, Compose UI compile, installing/running on a device or against real Instagram -
the sandbox cannot reach the Android SDK or Maven. The first GitHub build is the real compile test.

## Known issues / limits
- Instagram tab ids/labels in `InstagramScreenDetector` are from memory and unverified against a live app. If they are wrong,
  the app fails open (nothing filtered) rather than reading unknown screens.
- Stories and unrecognised screens are not filtered. Reels/posts with little text are "uncertain" and blocked.
- Whole-screen judging: if an educational post and a meme are both visible, the screen is usually blocked.
- Syllabus list is a starter list; verify against cbseacademic.nic.in and switch off removed chapters in the Syllabus tab.
  Hindi समास/अलंकार and Class-10 IT start OFF/optional as unconfirmed.
- Keyword matching is not real understanding; hashtag-stuffed memes are caught only if they contain distraction words.
- Debug-signed APK only (fine for personal sideloading).
