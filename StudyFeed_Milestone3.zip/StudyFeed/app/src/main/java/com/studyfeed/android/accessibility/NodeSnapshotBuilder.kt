package com.studyfeed.android.accessibility

import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo

/** Copies the VISIBLE part of an Instagram window into a [NodeSnapshot]. Never copies password/editable text. */
object NodeSnapshotBuilder {
    private const val MAX_DEPTH = 30
    private const val MAX_NODES = 700

    fun build(root: AccessibilityNodeInfo): NodeSnapshot {
        val budget = intArrayOf(MAX_NODES)
        return copy(root, 0, budget)
    }

    private fun copy(node: AccessibilityNodeInfo, depth: Int, budget: IntArray): NodeSnapshot {
        budget[0]--
        val sensitive = node.isPassword || node.isEditable
        val visible = node.isVisibleToUser
        val kids = ArrayList<NodeSnapshot>()
        if (depth < MAX_DEPTH) {
            for (i in 0 until node.childCount) {
                if (budget[0] <= 0) break
                val child = node.getChild(i) ?: continue
                try {
                    kids += copy(child, depth + 1, budget)
                } finally {
                    @Suppress("DEPRECATION")
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) child.recycle()
                }
            }
        }
        return NodeSnapshot(
            text = if (sensitive || !visible) null else node.text?.toString(),
            description = if (sensitive || !visible) null else node.contentDescription?.toString(),
            viewId = node.viewIdResourceName,
            selected = node.isSelected,
            editable = sensitive,
            children = kids
        )
    }
}
