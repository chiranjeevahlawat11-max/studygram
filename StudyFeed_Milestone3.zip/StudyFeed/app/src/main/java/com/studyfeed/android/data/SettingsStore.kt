package com.studyfeed.android.data

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.studyfeed.android.accessibility.StudyFeedAccessibilityService
import com.studyfeed.android.classifier.Decision
import com.studyfeed.android.syllabus.NcertSyllabus

data class Stats(
    val allowed: Long, val blockedUnrelated: Long, val blockedUncertain: Long, val sinceMs: Long
) {
    val blocked: Long get() = blockedUnrelated + blockedUncertain
    val total: Long get() = allowed + blocked
}

/**
 * Local-only storage (SharedPreferences, private to this app). Holds switches, enabled chapters
 * and anonymous counters. It never stores captions, usernames or any Instagram text.
 */
class SettingsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("studyfeed_prefs", Context.MODE_PRIVATE)

    fun protectionState(): ProtectionPolicy.State = ProtectionPolicy.State(
        enabled = prefs.getBoolean(K_ENABLED, true),
        disableRequestedAt = prefs.getLong(K_DISABLE_AT, 0L)
    )

    fun saveProtectionState(s: ProtectionPolicy.State) {
        prefs.edit().putBoolean(K_ENABLED, s.enabled).putLong(K_DISABLE_AT, s.disableRequestedAt).apply()
    }

    fun enabledChapterIds(): Set<String> =
        if (prefs.contains(K_CHAPTERS)) prefs.getStringSet(K_CHAPTERS, null)?.toSet() ?: NcertSyllabus.defaultEnabledIds()
        else NcertSyllabus.defaultEnabledIds()

    fun setChapterEnabled(id: String, on: Boolean) {
        val set = enabledChapterIds().toMutableSet()
        if (on) set.add(id) else set.remove(id)
        prefs.edit().putStringSet(K_CHAPTERS, set).apply()
    }

    fun resetChapters() { prefs.edit().remove(K_CHAPTERS).apply() }

    fun record(decision: Decision) {
        val key = when (decision) {
            Decision.EDUCATIONAL -> K_ALLOWED
            Decision.UNRELATED -> K_UNRELATED
            Decision.UNCERTAIN -> K_UNCERTAIN
        }
        val e = prefs.edit().putLong(key, prefs.getLong(key, 0L) + 1)
        if (!prefs.contains(K_SINCE)) e.putLong(K_SINCE, System.currentTimeMillis())
        e.apply()
    }

    fun stats(): Stats {
        if (!prefs.contains(K_SINCE)) prefs.edit().putLong(K_SINCE, System.currentTimeMillis()).apply()
        return Stats(
            prefs.getLong(K_ALLOWED, 0L), prefs.getLong(K_UNRELATED, 0L), prefs.getLong(K_UNCERTAIN, 0L),
            prefs.getLong(K_SINCE, System.currentTimeMillis())
        )
    }

    fun resetStats() {
        prefs.edit().remove(K_ALLOWED).remove(K_UNRELATED).remove(K_UNCERTAIN)
            .putLong(K_SINCE, System.currentTimeMillis()).apply()
    }

    /** Heartbeat so the app can show "service last saw Instagram at ...". */
    fun touchHeartbeat(now: Long) {
        if (now - prefs.getLong(K_HEARTBEAT, 0L) > 5_000L) prefs.edit().putLong(K_HEARTBEAT, now).apply()
    }

    fun lastHeartbeat(): Long = prefs.getLong(K_HEARTBEAT, 0L)

    companion object {
        private const val K_ENABLED = "protection_enabled"
        private const val K_DISABLE_AT = "disable_requested_at"
        private const val K_CHAPTERS = "enabled_chapters_v1"
        private const val K_ALLOWED = "stat_allowed"
        private const val K_UNRELATED = "stat_unrelated"
        private const val K_UNCERTAIN = "stat_uncertain"
        private const val K_SINCE = "stat_since"
        private const val K_HEARTBEAT = "heartbeat"

        fun isAccessibilityServiceEnabled(context: Context): Boolean {
            val me = ComponentName(context, StudyFeedAccessibilityService::class.java)
            val enabled = Settings.Secure.getString(
                context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
        }
    }
}
