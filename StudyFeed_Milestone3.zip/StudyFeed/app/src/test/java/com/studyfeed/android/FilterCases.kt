package com.studyfeed.android

import com.studyfeed.android.classifier.Decision
import com.studyfeed.android.classifier.Decision.EDUCATIONAL
import com.studyfeed.android.classifier.Decision.UNCERTAIN
import com.studyfeed.android.classifier.Decision.UNRELATED

data class FilterCase(val label: String, val text: String, val expected: Decision)

/** Hand-written examples used by both the JUnit tests and the local check runner. */
object FilterCases {
    val all = listOf(
        // ---- should be EDUCATIONAL ----
        FilterCase("ohm's law explainer",
            "Class 10 Physics: Ohm's law explained with numerical examples on electric current and resistance. Important for CBSE boards.", EDUCATIONAL),
        FilterCase("quadratic formula",
            "Quadratic equations Class 10 maths - discriminant and nature of roots, solved example with the quadratic formula. NCERT exercise 4.3", EDUCATIONAL),
        FilterCase("photosynthesis",
            "Photosynthesis class 10 science important questions: chlorophyll, stomata and the chemical equation. CBSE revision notes", EDUCATIONAL),
        FilterCase("nationalism history",
            "Nationalism in India: Non-Cooperation Movement and the Salt March explained for Class 10 CBSE history, chapter 2 notes", EDUCATIONAL),
        FilterCase("heredity",
            "Heredity chapter: Mendel's monohybrid cross, dominant trait and recessive trait with a worked example. NCERT class 10", EDUCATIONAL),
        FilterCase("federalism civics",
            "Federalism class 10 civics - union list, state list and concurrent list explained with definition and examples for boards", EDUCATIONAL),
        FilterCase("trig identities",
            "Introduction to trigonometry: trigonometric identities, sin theta and cos theta values. Class 10 solved question for CBSE", EDUCATIONAL),
        FilterCase("english lencho",
            "A Letter to God by Lencho - chapter summary and important questions, CBSE class 10 English First Flight notes", EDUCATIONAL),
        FilterCase("money and credit",
            "Money and credit class 10 economics: double coincidence of wants, barter system and modern forms of money. Explanation for boards", EDUCATIONAL),
        FilterCase("hindi balgobin",
            "कक्षा 10 क्षितिज: बालगोबिन भगत पाठ का सारांश और महत्वपूर्ण प्रश्न उत्तर, CBSE परीक्षा नोट्स", EDUCATIONAL),
        FilterCase("it spreadsheet",
            "Class 10 IT code 402: electronic spreadsheet VLOOKUP and pivot table tutorial with example for CBSE boards", EDUCATIONAL),
        FilterCase("human eye",
            "Human eye class 10: myopia, hypermetropia and presbyopia with ray diagram and definition - NCERT science revision", EDUCATIONAL),

        // ---- should be UNRELATED ----
        FilterCase("funny meme", "This meme is so funny, tag your friend who does this every single day lol trending viral", UNRELATED),
        FilterCase("gaming", "BGMI gameplay with new update, free fire vs pubg streamer rank push live tonight guys", UNRELATED),
        FilterCase("celebrity", "Bollywood celebrity spotted at airport, new movie trailer drops tomorrow, fans go crazy", UNRELATED),
        FilterCase("makeup", "GRWM for college fest: makeup, outfit and fashion haul, comment your favourite look below please", UNRELATED),
        FilterCase("dance reel", "Dance challenge with the new song, trending reel, follow for more daily dance videos and giveaway", UNRELATED),
        FilterCase("cricket", "Last night's cricket match was unbelievable, what a final over and what a crowd at the stadium today", UNRELATED),
        FilterCase("food vlog", "Sunday vlog: trying street food in the old city with my cousins and then a long walk by the river", UNRELATED),
        FilterCase("travel", "Sunrise at the hill station was breathtaking, clouds below us and hot tea in hand, best trip of the year", UNRELATED),
        FilterCase("hashtag stuffed meme",
            "funny meme prank comedy trending viral #ncert #cbse #class10 #boardexam follow for more", UNRELATED),
        FilterCase("whole-word check: baseball",
            "Baseball season opener: the placid crowd cheered as the home team scored a salty late win at the stadium", UNRELATED),
        FilterCase("personal development",
            "Personal development tips for a better morning routine and a calmer mind, small habits that changed my year", UNRELATED),
        FilterCase("single weak term (probability puzzles)",
            "I love probability puzzles and card tricks with my friends on weekends at home", UNRELATED),

        // ---- should be UNCERTAIN ----
        FilterCase("too short", "Class 10 maths", UNCERTAIN),
        FilterCase("no caption", "", UNCERTAIN),
        FilterCase("two topics, no teaching context",
            "Our teacher talked about photosynthesis and chlorophyll while we walked through the garden yesterday afternoon", UNCERTAIN),
        FilterCase("ui chrome only", "Like Comment Share Save", UNCERTAIN),
        FilterCase("one topic word, one signal",
            "photosynthesis reel", UNCERTAIN)
    )
}
