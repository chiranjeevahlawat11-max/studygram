package com.studyfeed.android

import com.studyfeed.android.accessibility.InstagramScreenDetector
import com.studyfeed.android.accessibility.InstagramSurface
import com.studyfeed.android.accessibility.NodeSnapshot
import com.studyfeed.android.classifier.ContentClassifier
import com.studyfeed.android.data.ProtectionPolicy
import com.studyfeed.android.syllabus.NcertSyllabus
import kotlin.system.exitProcess

/** Local runner (no JUnit needed): prints every case and exits non-zero on any failure. */
fun main() {
    var failures = 0
    fun check(name: String, ok: Boolean, detail: String = "") {
        println((if (ok) "PASS  " else "FAIL  ") + name + (if (!ok && detail.isNotEmpty()) "  -> $detail" else ""))
        if (!ok) failures++
    }

    println("== Classifier ==")
    for (c in FilterCases.all) {
        val r = ContentClassifier.classify(c.text)
        check("[${c.expected}] ${c.label}", r.decision == c.expected,
            "got ${r.decision} (topic=${r.topicScore} teach=${r.teachingSignals} distr=${r.distractionSignals}: ${r.reason})")
    }
    // disabling a chapter must stop it from counting
    val ohm = FilterCases.all.first { it.label == "ohm's law explainer" }
    val without = NcertSyllabus.defaultEnabledIds() - "sci-11"
    val r2 = ContentClassifier.classify(ohm.text, without)
    check("disabled chapter no longer approves", r2.decision != com.studyfeed.android.classifier.Decision.EDUCATIONAL, r2.reason)
    val hindiGrammar = ContentClassifier.classify("कक्षा 10 हिंदी व्याकरण: समास और अलंकार की परिभाषा, उदाहरण सहित प्रश्न उत्तर नोट्स")
    check("unconfirmed chapter (समास/अलंकार) starts disabled -> not approved by that chapter alone",
        !hindiGrammar.matchedChapterIds.contains("hin-6"), hindiGrammar.matchedChapterIds.toString())

    println("== Syllabus data ==")
    val ids = NcertSyllabus.allChapters.map { it.id }
    check("chapter ids unique", ids.size == ids.toSet().size)
    check("every chapter has keywords", NcertSyllabus.allChapters.all { it.keywords.isNotEmpty() })
    println("      ${NcertSyllabus.subjects.size} subjects, ${ids.size} chapters, ${NcertSyllabus.allChapters.sumOf { it.keywords.size }} keywords")

    println("== Screen detector ==")
    fun tab(id: String, desc: String, sel: Boolean) =
        NodeSnapshot(viewId = "com.instagram.android:id/$id", description = desc, selected = sel)
    fun screen(selectedTab: String, vararg extra: NodeSnapshot) = NodeSnapshot(children = listOf(
        tab("feed_tab", "Home", selectedTab == "feed"),
        tab("search_tab", "Search and explore", selectedTab == "search"),
        tab("clips_tab", "Reels", selectedTab == "reels"),
        tab("profile_tab", "Profile", selectedTab == "profile"),
        *extra))
    check("home tab -> FEED", InstagramScreenDetector.detect(screen("feed")) == InstagramSurface.FEED)
    check("reels tab -> REELS", InstagramScreenDetector.detect(screen("reels")) == InstagramSurface.REELS)
    check("search tab -> EXPLORE", InstagramScreenDetector.detect(screen("search")) == InstagramSurface.EXPLORE)
    check("profile tab -> PROFILE", InstagramScreenDetector.detect(screen("profile")) == InstagramSurface.PROFILE)
    check("no tab bar -> OTHER (not inspected)", InstagramScreenDetector.detect(NodeSnapshot(text = "Welcome")) == InstagramSurface.OTHER)
    check("no selected tab -> OTHER", InstagramScreenDetector.detect(screen("none")) == InstagramSurface.OTHER)
    val dm = screen("feed", NodeSnapshot(viewId = "com.instagram.android:id/row_thread_composer_edittext"))
    check("DM thread id -> MESSAGES", InstagramScreenDetector.detect(dm) == InstagramSurface.MESSAGES)
    val reqs = screen("feed", NodeSnapshot(text = "Message requests"))
    check("'Message requests' label -> MESSAGES", InstagramScreenDetector.detect(reqs) == InstagramSurface.MESSAGES)
    val primaryPost = screen("feed", NodeSnapshot(text = "Primary colours and general audio explore: class 10 notes"))
    check("post text with 'primary/general/audio/explore' is still FEED (old bypass bug)",
        InstagramScreenDetector.detect(primaryPost) == InstagramSurface.FEED)
    val withEditable = screen("search",
        NodeSnapshot(text = "my secret search", editable = true), NodeSnapshot(text = "Visible caption text"))
    val extracted = InstagramScreenDetector.extractContentText(withEditable)
    check("typed text (editable) never extracted", !extracted.contains("secret") && extracted.contains("Visible caption"), extracted)
    check("tab labels excluded from content text", !extracted.contains("Reels") && !extracted.contains("Home"), extracted)

    println("== Protection policy ==")
    val t0 = 1_000_000L
    var s = ProtectionPolicy.State()
    check("active by default", ProtectionPolicy.isActive(s, t0))
    s = ProtectionPolicy.requestDisable(s, t0)
    check("still active right after disable request", ProtectionPolicy.isActive(s, t0 + 1000))
    check("still active just before cooldown ends", ProtectionPolicy.isActive(s, t0 + ProtectionPolicy.COOLDOWN_MS - 1))
    check("inactive after cooldown", !ProtectionPolicy.isActive(s, t0 + ProtectionPolicy.COOLDOWN_MS))
    check("remaining time counts down", ProtectionPolicy.remainingMs(s, t0 + 60_000) == ProtectionPolicy.COOLDOWN_MS - 60_000)
    check("second request does not restart timer", ProtectionPolicy.requestDisable(s, t0 + 5000).disableRequestedAt == t0)
    check("cancel keeps protection on", ProtectionPolicy.isActive(ProtectionPolicy.cancelDisable(s), t0 + ProtectionPolicy.COOLDOWN_MS + 5))
    check("resolve collapses expired request", !ProtectionPolicy.resolve(s, t0 + ProtectionPolicy.COOLDOWN_MS).enabled)
    check("enable resets", ProtectionPolicy.isActive(ProtectionPolicy.enable(), t0))

    println(if (failures == 0) "\nALL CHECKS PASSED" else "\n$failures CHECK(S) FAILED")
    exitProcess(if (failures == 0) 0 else 1)
}
