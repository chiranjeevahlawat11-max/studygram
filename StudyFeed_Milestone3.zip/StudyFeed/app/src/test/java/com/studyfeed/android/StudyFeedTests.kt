package com.studyfeed.android

import com.studyfeed.android.accessibility.InstagramScreenDetector
import com.studyfeed.android.accessibility.InstagramSurface
import com.studyfeed.android.accessibility.NodeSnapshot
import com.studyfeed.android.classifier.ContentClassifier
import com.studyfeed.android.classifier.Decision
import com.studyfeed.android.data.ProtectionPolicy
import com.studyfeed.android.syllabus.NcertSyllabus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClassifierTest {
    @Test fun labelledExamplesAreClassifiedAsExpected() {
        val wrong = FilterCases.all.filter { ContentClassifier.classify(it.text).decision != it.expected }
        assertTrue("Misclassified: " + wrong.joinToString { it.label }, wrong.isEmpty())
    }

    @Test fun disabledChapterNoLongerApproves() {
        val ohm = FilterCases.all.first { it.label == "ohm's law explainer" }
        val r = ContentClassifier.classify(ohm.text, NcertSyllabus.defaultEnabledIds() - "sci-11")
        assertFalse(r.decision == Decision.EDUCATIONAL)
    }

    @Test fun chapterIdsAreUnique() {
        val ids = NcertSyllabus.allChapters.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }
}

class DetectorTest {
    private fun tab(id: String, desc: String, sel: Boolean) =
        NodeSnapshot(viewId = "com.instagram.android:id/$id", description = desc, selected = sel)

    private fun screen(selected: String, vararg extra: NodeSnapshot) = NodeSnapshot(children = listOf(
        tab("feed_tab", "Home", selected == "feed"), tab("search_tab", "Search and explore", selected == "search"),
        tab("clips_tab", "Reels", selected == "reels"), tab("profile_tab", "Profile", selected == "profile"), *extra))

    @Test fun tabsMapToSurfaces() {
        assertEquals(InstagramSurface.FEED, InstagramScreenDetector.detect(screen("feed")))
        assertEquals(InstagramSurface.REELS, InstagramScreenDetector.detect(screen("reels")))
        assertEquals(InstagramSurface.EXPLORE, InstagramScreenDetector.detect(screen("search")))
    }

    @Test fun unknownScreenIsNotInspected() {
        assertEquals(InstagramSurface.OTHER, InstagramScreenDetector.detect(NodeSnapshot(text = "Welcome")))
    }

    @Test fun messagesAreDetectedStructurally() {
        val dm = screen("feed", NodeSnapshot(viewId = "com.instagram.android:id/row_thread_composer_edittext"))
        assertEquals(InstagramSurface.MESSAGES, InstagramScreenDetector.detect(dm))
    }

    @Test fun postTextWithOldTriggerWordsIsStillFeed() {
        val post = screen("feed", NodeSnapshot(text = "Primary colours and general audio explore: class 10 notes"))
        assertEquals(InstagramSurface.FEED, InstagramScreenDetector.detect(post))
    }

    @Test fun typedTextIsNeverExtracted() {
        val s = screen("search", NodeSnapshot(text = "my secret search", editable = true), NodeSnapshot(text = "Caption"))
        val text = InstagramScreenDetector.extractContentText(s)
        assertFalse(text.contains("secret"))
        assertTrue(text.contains("Caption"))
    }
}

class ProtectionPolicyTest {
    @Test fun disableOnlyTakesEffectAfterCooldown() {
        val t0 = 1_000_000L
        val s = ProtectionPolicy.requestDisable(ProtectionPolicy.State(), t0)
        assertTrue(ProtectionPolicy.isActive(s, t0 + ProtectionPolicy.COOLDOWN_MS - 1))
        assertFalse(ProtectionPolicy.isActive(s, t0 + ProtectionPolicy.COOLDOWN_MS))
    }

    @Test fun cancelKeepsProtectionOn() {
        val t0 = 5L
        val s = ProtectionPolicy.cancelDisable(ProtectionPolicy.requestDisable(ProtectionPolicy.State(), t0))
        assertTrue(ProtectionPolicy.isActive(s, t0 + ProtectionPolicy.COOLDOWN_MS + 1))
    }
}
