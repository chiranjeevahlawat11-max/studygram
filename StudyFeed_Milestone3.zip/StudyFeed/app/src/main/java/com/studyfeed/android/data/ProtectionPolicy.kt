package com.studyfeed.android.data

/**
 * "No ordinary bypass" rule, implemented as a delay-to-disable.
 * Turning protection off inside the app only takes effect after [COOLDOWN_MS].
 * Pure Kotlin (no Android classes) so it can be unit-tested.
 *
 * This is friction, not a lock: the user can still revoke Accessibility or uninstall in Android Settings.
 */
object ProtectionPolicy {
    const val COOLDOWN_MS: Long = 10 * 60 * 1000L

    data class State(val enabled: Boolean = true, val disableRequestedAt: Long = 0L)

    fun isActive(s: State, now: Long): Boolean = when {
        !s.enabled -> false
        s.disableRequestedAt <= 0L -> true
        else -> now < s.disableRequestedAt + COOLDOWN_MS
    }

    fun isDisablePending(s: State, now: Long): Boolean =
        s.enabled && s.disableRequestedAt > 0L && now < s.disableRequestedAt + COOLDOWN_MS

    fun remainingMs(s: State, now: Long): Long =
        if (isDisablePending(s, now)) s.disableRequestedAt + COOLDOWN_MS - now else 0L

    fun requestDisable(s: State, now: Long): State =
        if (!s.enabled || s.disableRequestedAt > 0L) s else s.copy(disableRequestedAt = now)

    fun cancelDisable(s: State): State = s.copy(disableRequestedAt = 0L)

    /** Collapse an expired request into a plain "disabled" state. */
    fun resolve(s: State, now: Long): State =
        if (s.enabled && s.disableRequestedAt > 0L && now >= s.disableRequestedAt + COOLDOWN_MS)
            State(enabled = false, disableRequestedAt = 0L)
        else s

    fun enable(): State = State(enabled = true, disableRequestedAt = 0L)
}
