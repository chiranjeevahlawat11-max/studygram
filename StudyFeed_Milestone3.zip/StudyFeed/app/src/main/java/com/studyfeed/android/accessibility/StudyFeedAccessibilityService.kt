package com.studyfeed.android.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.studyfeed.android.classifier.ContentClassifier
import com.studyfeed.android.classifier.Decision
import com.studyfeed.android.data.ProtectionPolicy
import com.studyfeed.android.data.SettingsStore

/**
 * Instagram-only filter.
 *  - Content (text) is read ONLY when the active window belongs to com.instagram.android.
 *  - Nothing is logged with content, stored, or sent anywhere. No INTERNET permission exists.
 *  - Only EDUCATIONAL screens are left visible; everything else gets a blocking overlay with
 *    "Next post" (scrolls on, then re-checks) and "Leave Instagram". There is no "show anyway".
 *
 * The service receives lightweight events from all apps (Android's accessibility config cannot
 * list "Instagram + whatever launcher you use"), but returns immediately for any other package.
 */
class StudyFeedAccessibilityService : AccessibilityService() {

    private lateinit var store: SettingsStore
    private var windowManager: WindowManager? = null
    private val handler = Handler(Looper.getMainLooper())

    private var shield: View? = null
    private var shieldMessage: TextView? = null
    private var shieldParams: WindowManager.LayoutParams? = null

    private var lastHash = 0
    private var lastDecision: Decision? = null
    private var evaluatePending = false
    private var imePackages: Set<String> = emptySet()

    private val evaluateRunnable = Runnable { evaluatePending = false; evaluateSafely() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = SettingsStore(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        refreshImePackages()
        Log.i(TAG, "service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg != INSTAGRAM_PACKAGE) {
            // Our own overlay, the status bar and keyboards must not count as "left Instagram".
            val transient = pkg == packageName || pkg == "com.android.systemui" || pkg in imePackages
            if (!transient && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                hideShield(); resetCache()
            }
            return
        }
        scheduleEvaluate(DEBOUNCE_MS)
    }

    private fun scheduleEvaluate(delayMs: Long) {
        if (evaluatePending) return
        evaluatePending = true
        handler.postDelayed(evaluateRunnable, delayMs)
    }

    private fun evaluateSafely() {
        try { evaluate() } catch (e: Exception) { Log.e(TAG, "evaluate failed: ${e.javaClass.simpleName}") }
    }

    private fun evaluate() {
        val now = System.currentTimeMillis()
        if (!ProtectionPolicy.isActive(store.protectionState(), now)) { hideShield(); resetCache(); return }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return // never read other apps

        store.touchHeartbeat(now)
        val snapshot = NodeSnapshotBuilder.build(root)
        val surface = InstagramScreenDetector.detect(snapshot)
        if (surface != InstagramSurface.FEED && surface != InstagramSurface.REELS && surface != InstagramSurface.EXPLORE) {
            // Messages, profile, login, settings, unknown: not inspected, not blocked.
            hideShield(); resetCache(); return
        }

        val text = InstagramScreenDetector.extractContentText(snapshot)
        val hash = text.hashCode()
        if (hash == lastHash && lastDecision != null) return
        lastHash = hash

        val result = ContentClassifier.classify(text, store.enabledChapterIds())
        lastDecision = result.decision
        store.record(result.decision)
        Log.d(TAG, "surface=$surface decision=${result.decision} topic=${result.topicScore}") // no content logged

        when (result.decision) {
            Decision.EDUCATIONAL -> hideShield()
            Decision.UNRELATED -> showShield("Blocked: this doesn't look like Class 10 study content.")
            Decision.UNCERTAIN -> showShield("Blocked: StudyFeed can't tell if this is study content.")
        }
    }

    private fun resetCache() { lastHash = 0; lastDecision = null }

    // ---- overlay -------------------------------------------------------------------------

    private fun showShield(message: String) {
        shieldMessage?.let { it.text = message; return }
        val ctx = this
        val panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 64, 48, 64)
            setBackgroundColor(0xFF0B1B2B.toInt())
            addView(TextView(ctx).apply {
                text = "StudyFeed"; textSize = 28f; gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
            })
            val msg = TextView(ctx).apply {
                text = message; textSize = 17f; gravity = Gravity.CENTER
                setTextColor(0xFFCBD5E1.toInt()); setPadding(0, 28, 0, 36)
            }
            shieldMessage = msg
            addView(msg)
            addView(Button(ctx).apply { text = "Next post"; setOnClickListener { skipToNext() } })
            addView(Button(ctx).apply {
                text = "Leave Instagram"
                setOnClickListener { hideShield(); resetCache(); performGlobalAction(GLOBAL_ACTION_HOME) }
            })
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try {
            windowManager?.addView(panel, params)
            shield = panel; shieldParams = params
        } catch (e: Exception) {
            shieldMessage = null
            Log.e(TAG, "cannot show shield: ${e.javaClass.simpleName}")
        }
    }

    private fun hideShield() {
        val v = shield ?: return
        try { windowManager?.removeView(v) } catch (_: Exception) { }
        shield = null; shieldMessage = null; shieldParams = null
    }

    private fun setShieldTouchable(touchable: Boolean) {
        val v = shield ?: return
        val p = shieldParams ?: return
        p.flags = if (touchable) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { windowManager?.updateViewLayout(v, p) } catch (_: Exception) { }
    }

    // ---- "Next post" ---------------------------------------------------------------------
    // The overlay stays up while we scroll; the re-check afterwards removes it only if the new
    // content is EDUCATIONAL, so unrelated content is not exposed in between.

    private fun skipToNext() {
        resetCache()
        val root = rootInActiveWindow
        val scrolled = root != null && root.packageName?.toString() == INSTAGRAM_PACKAGE &&
            findScrollable(root)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true
        if (scrolled) { scheduleEvaluate(700L); return }

        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(dm.widthPixels * 0.5f, dm.heightPixels * 0.75f)
            lineTo(dm.widthPixels * 0.5f, dm.heightPixels * 0.25f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 250L)).build()
        setShieldTouchable(false) // let the swipe reach Instagram instead of our own overlay
        val started = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { setShieldTouchable(true); scheduleEvaluate(700L) }
            override fun onCancelled(g: GestureDescription?) { setShieldTouchable(true); scheduleEvaluate(300L) }
        }, null)
        if (!started) { setShieldTouchable(true); scheduleEvaluate(300L) }
    }

    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < 800) {
            val n = stack.removeLast(); visited++
            if (n.isScrollable && n.isVisibleToUser) return n
            for (i in n.childCount - 1 downTo 0) n.getChild(i)?.let(stack::addLast)
        }
        return null
    }

    private fun refreshImePackages() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imePackages = imm?.enabledInputMethodList?.map { it.packageName }?.toSet().orEmpty()
    }

    override fun onInterrupt() { hideShield(); resetCache() }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        handler.removeCallbacksAndMessages(null); hideShield(); return super.onUnbind(intent)
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); hideShield(); super.onDestroy() }

    companion object {
        private const val TAG = "StudyFeed"
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        private const val DEBOUNCE_MS = 350L
    }
}
